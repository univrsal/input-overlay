input-overlay v4.8b
github.com/univrsal/input-overlay

licensed under the GPL v2.0, see LICENSE

Installation:
=============

1. Open your obs-studio installation directory (eg. rightclick the obs shortcut and click "open file location")
2. Go up two directories
3. Copy the contents of the "plugin" folder into the obs directory
4. Copy and extract any presets you want to use
