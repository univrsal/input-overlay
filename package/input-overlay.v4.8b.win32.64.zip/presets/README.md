These are only the latest preset versions.
You should always use the presets shipped with the version you downloaded.
